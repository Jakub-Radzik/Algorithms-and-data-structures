package Interfaces;

public interface Predicate<T>{
    boolean accept(T arg);
}
