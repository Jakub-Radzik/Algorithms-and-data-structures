package Interfaces;

public interface Iterator1b<T> {
    void first();
    void next();
    boolean isDone();
    T currentItem();
}
