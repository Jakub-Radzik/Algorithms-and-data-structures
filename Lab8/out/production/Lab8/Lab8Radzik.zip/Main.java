import Zadanie1.HeapPriorityQueue;

import java.util.Random;

public class Main {
    public static void main(String[] args) throws Exception {
        //ARRAY GENERATION
        int[] tab = new int[16];
        Random rand = new Random();
        int n;

        for (int i = 0; i < tab.length; i++) {
            n = rand.nextInt(500);
            tab[i] = n;
        }

        //CREATE HEAP PRIORITY QUEUE
        HeapPriorityQueue heap = new HeapPriorityQueue(tab);
        heap.print();
        heap.dequeue();
        heap.print();




    }
}
